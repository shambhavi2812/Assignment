package nagarro.controller;
import nagarro.domain.*;
import nagarro.view.*;
import nagarro.service.*;

public class Application{
	public static void main(String[]args) {
		
		//input
		Input in = new Input();
		Car car = in.getData();
		
		//generate results
		InsuranceCalculationService calc = new InsuranceCalculationService();
		car = calc.calculatePremium(car);
		
		//output
		Output out = new Output();
		out.display(car);
	}
}
	
	
	


