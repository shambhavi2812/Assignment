package nagarro.domain;

public class Car {
	private String carModel;
	private CarType CarType;
	private InsuranceType insuranceType;
	private double carPrice;
	private double totalPremium;
	
	
	public String getCarModel() {
		return carModel;
	}
	public void setCarModel(String carModel) {
		this.carModel = carModel;
	}
	public CarType getCarType() {
		return CarType;
	}
	public void setCarType(CarType carType) {
		CarType = carType;
	}
	public InsuranceType getInsuranceType() {
		return insuranceType;
	}
	public void setInsuranceType(InsuranceType insuranceType) {
		this.insuranceType = insuranceType;
	}
	public double getCarPrice() {
		return carPrice;
	}
	public void setCarPrice(double carPrice) {
		this.carPrice = carPrice;
	}
	public double getTotalPremium() {
		return totalPremium;
	}
	public void setTotalPremium(double totalPremium) {
		this.totalPremium = totalPremium;
	}
}	
	
	