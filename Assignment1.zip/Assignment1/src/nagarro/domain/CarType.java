package nagarro.domain;

public enum CarType {
	HATCHBACK,SEDAN,SUV;
}
