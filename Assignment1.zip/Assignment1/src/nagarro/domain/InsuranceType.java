package nagarro.domain;

public enum InsuranceType {
	BASIC,PREMIUM;

}
