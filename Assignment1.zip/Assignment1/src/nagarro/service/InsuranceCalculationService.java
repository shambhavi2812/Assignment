package nagarro.service;
import nagarro.domain.Car;
public class InsuranceCalculationService{
	public Car calculatePremium(Car car) {
		double totalPremium = 0.0;
		switch(car.getCarType()) {
		case HATCHBACK:
			totalPremium = (0.05 * car.getCarPrice());
			break;
		case SEDAN:
			totalPremium = (0.08 * car.getCarPrice());
			break;
		case SUV:
			totalPremium = (0.1 * car.getCarPrice());
			break;
		default :{
			System.out.println("Invalid CarType");
		}
		}
		if ("basic".equals(car.getInsuranceType())) {
			totalPremium = totalPremium;
		} else if ("premium".equals(car.getInsuranceType())) {
				totalPremium = (totalPremium * 0.20)+ totalPremium;
		}
		car.setTotalPremium(totalPremium);
			return car;
		}
	}
	
