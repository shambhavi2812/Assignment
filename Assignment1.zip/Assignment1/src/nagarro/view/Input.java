package nagarro.view;

import java.util.Scanner;

import nagarro.domain.Car;
import nagarro.domain.CarType;
import nagarro.domain.InsuranceType;


public class Input {

	public Car getData() {
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Ënter the car type:");
		String type = scan.next();
		CarType carType = CarType.valueOf(type);
	
		System.out.println("Ënter the car model:");
		String model= scan.next();
		
		System.out.println("Ënter the car cost price:");
		String price = scan.next();
		double cost = Double.parseDouble(price);
		
		System.out.println("Enter Insurance Type: basic or premium");
		String insurancetype = scan.next();
		InsuranceType insuranceType = InsuranceType.valueOf(insurancetype);
		
		Car car = new Car();
		car.setCarType(carType);
		car.setInsuranceType(insuranceType);
		car.setCarPrice(cost);
		car.setCarModel(model);
		return car;
		
	}
}
