package nagarro.view;
import nagarro.domain.Car;
public class Output {
	public void display(Car car) {
		
		System.out.println("Car Model:"+car.getCarModel());
		System.out.println("Car Price:"+car.getCarPrice());
		System.out.println("Totalinsurance:"+car.getTotalPremium());
	}

}
